public class Referral {
    public static void main(String[] args) {
        String name = "Dr. Katz, Professional Therapist"; //Hardcode all information
        String address = "42 Meaning Ln., Life, AZ";
        String phone = "(911) 911 - 9119";
        String description = "Dr. Katz will happily guide you through any problems you might be having! His specialties include guitar, a laid back attitude, and... Whoops, you know what the music means... our time is up";
        System.out.println(name + "\n" + address + "\n" + phone + "\n" + description); //Concatenate all the strings together with new lines between each
    }
}