
public interface FCFType1 {
	public int execute(int x, int y);
}
