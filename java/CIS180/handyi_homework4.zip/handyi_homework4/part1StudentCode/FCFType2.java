
public interface FCFType2 {
	public void execute(String s, int y);
}
