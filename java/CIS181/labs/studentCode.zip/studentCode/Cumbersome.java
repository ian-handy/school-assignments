/* 
 * Instructor/Programmer: Clinton Rogers
 * Date: 3/27/2023
 * Any documents, source code, or work you create/modify as a result of this project is the 
 * property of the University of Massachusetts Dartmouth.  This document and any and all source 
 * code cannot be shared with anyone except: University of Massachusetts Dartmouth faculty 
 * (including TA�s), and in a private digital portfolio (public access online is prohibited) 
 * with the intention of applying to jobs and internships. These exceptions are non-transferable. 
 * Failure to comply is, at the very least, an academic infraction that could result in dismissal 
 * from the university. 
 * 
 * Student Name:
 * Date:
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.IntStream;

public class Cumbersome {

	public static void main(String[] args) {
		int list[] = null;

		File f = new File("numbers15.txt");

		Scanner fileInput;
		try {
			fileInput = new Scanner(f);


			int size = fileInput.nextInt();

			list = new int[size];

			//Generate 200 random numbers and add them to list.
			for(int x = 0; x<list.length;x++)
			{
				list[x]=fileInput.nextInt();
			}
			fileInput.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if(list == null)
		{
			System.out.println("Yo, you did not import the numbers file correctly.");
			System.out.println("Is it in the src folder by accident and not the ");
			System.out.println("project folder? Maybe you spelled it wrong in the code?");

			return;
		}

		
		//Make a new array that contains all numbers to positive numbers, but turn them all positive
		//IntStream streamAbsoluteList = Arrays.stream(list).map(value -> Math.abs(value));
		
		//Fill in your code here
		
		
		//Make a new array that only contains the negative numbers from list
		//must be exactly the right size.
		//IntStream streamNegativeList = Arrays.stream(list).filter(i -> i<0);
		
		//Fill in your code here
		//Hint... first count up how many negatives exist in list (for loop)
		//next create the array with that count.
		//next copy only the negative values from list into the new array (for loop)

		//Print the sum of the original list
		//int sumList = Arrays.stream(list).sum();
		int sumList = 0;

		//Fill in your code here
		
		System.out.println("Original List Sum: " + sumList);

		//Print the sum of the as if all values are positive
		sumList = 0;
	
		//Fill in your code here
		
		System.out.println("Absolute List Sum: " + sumList);

		//Print the sum of just the negative numbers from the  original list
		//sumList = streamNegativeList.sum();
		sumList = 0;
		
		//Fill in your code here
		
		System.out.println("Sum of just the negative values: " +sumList);

		//Get the sum of numbers not divisible by 4 from list
		//sumList = Arrays.stream(list).filter(value -> (value % 4) !=0) .reduce(0, (runningTotal,nextValue) -> runningTotal + nextValue);
		sumList = 0;
		
		//Fill in your code here
		
		System.out.println("Original List Sum, but only numbers not divisible by 4 using reduce: " + sumList);

		//print out only even numbers from the original list:
		System.out.println("Even numbers from the list:");
		
		//Fill in your code here
		
		System.out.println();

		//get the result of multiplying all non-zero numbers in the list together:
		int product = 1;
		
		//Fill in your code here
		
		System.out.println("Product: " + product);
		
	}


}
