/*
 * Clinton Rogers
 * Lab9
 */

import MyADTStack.*;

public class StringRecognizer {

	/**
	 * precondition: none
	 * @param s: input string for testing
	 * @return true is s is in the language L = {w$w': w is a possibly empty string of characters
	 * 			other than $, w' = reverse(w)}; otherwise return false.
	 */
	boolean recognizeString(String s, boolean arrayBasedStack){	
		int index = 0;
		
		StackInterface<Character> myStack;
		
		if(arrayBasedStack)
		{
			myStack = new StackArrayBased<Character>();
		}else
		{
			myStack = new StackLinkedListBased<Character>();
		}
		
		
		//while we haven't hit the end of the string (there was no $ sign) and we haven't found the money sign
		
			//go ahead and push the character onto the stack
	
		
		//if the index and the length of the string are the same, that means there is no $?  return false now.
		
		//otherwise, we can advance beyond the money signed and compare the rest of the characters
		//one by one as we pop off the stack. (For loop probably useful here)
			//return false if a condition arises where we know s is not in this language
		
		//if we made it this far, are there any other conditions that would signify s is no in the language?

		
		//made it through all the checks without returning false, s must be in the language
		return true;
	}
	
}
