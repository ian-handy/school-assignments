/*
 * Clinton Rogers
 * Lab9
 */

package MyADTStack;

public class StackLinkedListBased<T> implements StackInterface<T>{

	//linked list head point, no dummy node
	private Node<T> head = null;

	public boolean isEmpty() {
		// TODO Auto-generated method stub
		//tis empty if the head is point to null
		return head == null;
	}

	public boolean isFull() {
		return false; //linked lists are never full
	}
	
	@Override
	public void popAll() {
		//TODO:make the linked list empty
	}

	@Override
	public void push(T newItem) throws StackException {

		//TODO:in what case would we want to throw an exception? Hint, look at push in StackArrayBased

		
		//TODO: create a new node, and insert it at the beginning of the linked list.
		
	}

	@Override
	public T pop() throws StackException {
		//TODO:in what case would we want to throw an exception? Hint, look at pop in StackArrayBased

		
		//TODO:temporarily grab hold of the data with a temp pointer of type T
		
		
		//TODO:Bypass the head pointer so it points to the second node in the list
		
		
		//TODO:get rid of null below and return that temp pointer.
		//return null;
	}

	@Override
	public T peek() throws StackException {
		//TODO:in what case would we want to throw an exception? Hint, look at peek in StackArrayBased
		
		//TODO:get rid of null below and return the data at the beginning of the linked list/top of the stack
		return null;
	}

}

class Node<E>
{
	private E data;
	private Node<E> next;
	
	public E getData() {
		return data;
	}
	public void setData(E data) {
		this.data = data;
	}
	public Node<E> getNext() {
		return next;
	}
	public void setNext(Node<E> next) {
		this.next = next;
	}
}